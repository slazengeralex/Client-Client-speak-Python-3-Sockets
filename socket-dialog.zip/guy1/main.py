import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.bind(("127.0.0.1", 8889))
cc = 0
flag = "0"
client = socket.socket()
while True:
    try:
        s.connect(("127.0.0.1", 8888))
        print("You have connected")
        flag = "1"
        break
    except:
        s.listen()
        client, addr = s.accept()
        print(addr, " has connected")
        flag = "0"
        cc = 1
        break


if cc == 1:
    while True:
        if flag == "0":
           data = client.recv(1024).decode()
           if data.lower() == "exit":
               print("Connection has ended")
               break
           print("New Message: ", data)
           flag = "1"
        elif flag == "1":
            message = input("Enter your message: ")
            client.send(message.encode())
            if message.lower() == "exit":
                print("You've finished your connection")
                break
            flag = "0"
else:
    while True:
        if flag == "0":
            data = s.recv(1024).decode()
            if data.lower() == "exit":
                print("Connection has ended")
                break
            print("New Message: ", data)
            flag = "1"
        elif flag == "1":
            message = input("Enter your message: ")
            s.send(message.encode())
            if message.lower() == "exit":
                print("You've finished your connection")
                break
            flag = "0"

client.close()
s.close()